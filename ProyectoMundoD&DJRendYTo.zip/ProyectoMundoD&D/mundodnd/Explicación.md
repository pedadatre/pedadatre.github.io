# Creo que solo he puesto funciones a las tarjetas :D

## showAlert()

- **Uso:** Muestra un mensaje de alerta cuando se hace clic en una tarjeta.


## openLink()

- **Uso:** Abre un enlace asociado a la tarjeta cuando se hace doble clic en ella.


## changeBackgroundColor()

- **Uso:** Cambia el color de fondo de una tarjeta cuando el cursor entra en ella.


## resetBackgroundColor()

- **Uso:** Restablece el color de fondo de una tarjeta cuando el cursor sale de ella.


# Funciones para Tarjetas con un Mensaje Flotante sacado de youtube porque me pareció buena idea 

## showFloatingMessage(message, x, y)

- **Uso:** Muestra un mensaje flotante cerca del raton cuando se mueve sobre una tarjeta.
- **Básicamente** Esta función lo que hace es que basado en donde esta el ratón con cordenadas X y Y hacemos
- que el mensaje con `(floatingMessage.offsetHeight + 10)` aparezca a 10 píxeles de distancia.
- Además para que el mensaje salga de horizontal al ratón usamos `(floatingMessage.offsetWidth)`.

## hideFloatingMessage()íxeles 

- **Uso:** Oculta el mensaje flotante cuando el raton sale de la tarjeta.

# Asignación de Eventos

Para asignar todos los eventos ponemos `addEventListener()`.
