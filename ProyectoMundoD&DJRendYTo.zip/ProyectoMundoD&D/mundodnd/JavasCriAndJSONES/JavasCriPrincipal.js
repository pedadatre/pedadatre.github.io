

document.addEventListener('DOMContentLoaded', function() {
    function showAlert() {
        alert( this.innerText + '!');
    }

    function openLink() {
        const link = this.querySelector('a');
        if (link) {
            window.location.href = link.href;
        }
    }

    function changeBackgroundColor() {
        this.style.backgroundColor = 'lightblue';
    }

    function resetBackgroundColor() {
        this.style.backgroundColor = '';
    }

    const tarjetas = document.querySelectorAll('.card');
    tarjetas.forEach(function(tarjeta) {
        tarjeta.addEventListener('click', showAlert);
        tarjeta.addEventListener('dblclick', openLink);
        tarjeta.addEventListener('mouseenter', changeBackgroundColor);
        tarjeta.addEventListener('mouseleave', resetBackgroundColor);
    });
});

document.addEventListener('DOMContentLoaded', function() {
    function showFloatingMessage(message, x, y) {
        const floatingMessage = document.getElementById('floatingMessage');
        floatingMessage.innerText = message;
        floatingMessage.style.display = 'block';
        floatingMessage.style.top = y - floatingMessage.offsetHeight - 10 + 'px';
        floatingMessage.style.left = x - floatingMessage.offsetWidth / 2 + 'px';
    }

    function hideFloatingMessage() {
        const floatingMessage = document.getElementById('floatingMessage');
        floatingMessage.style.display = 'none';
    }

    function changeBackgroundColor(event) {
        this.style.backgroundColor = 'lightblue';
        showFloatingMessage(this.innerText, event.clientX, event.clientY);
    }

    function resetBackgroundColor() {
        this.style.backgroundColor = '';
        hideFloatingMessage();
    }

    const tarjetas = document.querySelectorAll('.card');
    tarjetas.forEach(function(tarjeta) {
        tarjeta.addEventListener('mouseenter', changeBackgroundColor);
        tarjeta.addEventListener('mouseleave', resetBackgroundColor);
    });
});





